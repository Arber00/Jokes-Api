const JokesControllers = require('../controllers/jokes.controllers');

module.exports = app => {
    app.get('/api/jokes', JokesControllers.findAllJokes);
    app.post('/api/jokes', JokesControllers.createNewJoke);
    app.get('/api/jokes/:id', JokesControllers.findOneSingleJoke);
    app.put('/api/jokes/:id', JokesControllers.update_a_Joke);
    app.delete('/api/jokes/:id', JokesControllers.deleteAnExistingJoke);

}